

import { getState, dispatch } from './store';

console.log('--index.js--');

// window.getState = getState;
// window.dispatch = dispatch;


setInterval(() => {
  dispatch({ type: 'INC' });
  console.log(getState());
}, 1000);





