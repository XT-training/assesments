/**
 * Reducer - To mainupulate state & return the updated one
 */

const initalState = {
  num: 0,
  todos: [],
  data: "",
  users: null

}

/**
 * 
 * @param {Object} action 
 * @param {Object} state 
 */
function reducer(action, state = initalState) {
  switch (action.type) {
    case "INC":
      return {
        ...state,
        num: state.num + 1
      };
    case "DEC":
      return {
        ...state,
        num: state.num - 1
      };

    case "ADD_TODO":
      return {
        ...state,
        todos: [...state.todos, action.text]
      };

    case "GET_DATA":
      return {
        ...state,
        data: action.data
      };
    case 'GET_USERS':
      return {
        ...state,
        users: action.users

      }
    default:
      return state;
  }
}
export { reducer }